package com.shweta.catwalk.dao;

import com.shweta.catwalk.model.Users;

public interface UsersDAO {

		public void saveOrUpdate(Users users);

		public void delete(String id);

	}


