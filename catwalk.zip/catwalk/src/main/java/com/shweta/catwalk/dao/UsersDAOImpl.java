package com.shweta.catwalk.dao;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.shweta.catwalk.model.Users;

@Repository("UsersDAO")
public class UsersDAOImpl implements UsersDAO {
	
		@Autowired
		private SessionFactory sessionFactory;

		@Transactional
		public void saveOrUpdate(Users users) {
			sessionFactory.getCurrentSession().saveOrUpdate(users);
				
		}

		@Transactional
		public void delete(String id) {
			Users users = new Users();
			users.setId(id);
			sessionFactory.getCurrentSession().delete(users);
		}

}
