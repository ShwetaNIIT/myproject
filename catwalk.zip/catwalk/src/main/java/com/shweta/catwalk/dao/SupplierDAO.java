package com.shweta.catwalk.dao;

import java.util.List;

import com.shweta.catwalk.model.Supplier;

public interface SupplierDAO {
	public List<Supplier> list();

	public Supplier get(String id);
	
	public void saveOrUpdate(Supplier supplier);

	public String delete(String id);


}
