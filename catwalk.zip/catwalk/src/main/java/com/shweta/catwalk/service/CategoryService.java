package com.shweta.catwalk.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.shweta.catwalk.dao.CategoryDAOImpl;
import com.shweta.catwalk.model.Category;

@Service
@Transactional
public class CategoryService {
	@Autowired
	CategoryDAOImpl categoryDAO;
	public List<Category> list(){
		return categoryDAO.list();
	}
	public void saveOrUpdate(Category category){
		categoryDAO.saveOrUpdate(category);
	}
	public void delete(String id) {
		categoryDAO.delete(id);
		
	}
	public Category get(String id){
		return categoryDAO.get(id);
	}

}

