package com.shweta.catwalk.dao;

import java.util.List;

import com.shweta.catwalk.model.Category;

public interface CategoryDAO {
public void saveOrUpdate(Category category);
public void delete (String id);
public Category get(String id);

public List<Category> list();
}
