package com.shweta.catwalk.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
@Controller
public class Home {
 
		@RequestMapping("/")
		public String getHome()
		{
				return "Home";
		}
		@RequestMapping("/Home")
		public String getHome1()
		{
				return "Home";
		}
		@RequestMapping("/Login")
		public String getLogin()
		{
				return "Login";
		}
		@RequestMapping("/Form")
		public String getForm()
		{
				return "Form";
		}
		@RequestMapping("/Help")
		public String getHelp()
		{
				return "Help";
		}
		
		@RequestMapping("/Boots")
		public String getBoots()
		{
				return "Boots";
		}
		@RequestMapping("/Shoes")
		public String getShoes()
		{
				return "Shoes";
		}


}
