package com.shweta.catwalk.controller;

import org.springframework.web.bind.annotation.RequestMapping;

public class UsersController {
	@RequestMapping("/")
	public String getUsers()
	{
			return "Users";
	}

}
